package mx.edu.itspa.modelo;

import java.util.List;
import mx.edu.itspa.servicios.DetalleEntrega;

public class DetalleEntrega_Service {
    
    public DetalleEntrega_Service() { }
    
    public java.util.List<mx.edu.itspa.servicios.DetalleEntrega> ListarDetalleFacturaEntrega(){
        mx.edu.itspa.servicios.DetalleEntregaWebService_Service DESRV = new mx.edu.itspa.servicios.DetalleEntregaWebService_Service();
        mx.edu.itspa.servicios.DetalleEntregaWebService PORT = DESRV.getDetalleEntregaWebServicePort();
        
        return PORT.listarDetalleFacturaEntrega();
    }
    
    
    public java.util.List<mx.edu.itspa.servicios.DetalleEntrega> ListarPorId(int folio_entrega){
        mx.edu.itspa.servicios.DetalleEntregaWebService_Service DESRV = new mx.edu.itspa.servicios.DetalleEntregaWebService_Service();
        mx.edu.itspa.servicios.DetalleEntregaWebService PORT = DESRV.getDetalleEntregaWebServicePort();
        
        return PORT.listarDetalleEntregaPorId(folio_entrega);
    }
    
    
    public String Agregar(int folio_entrega, int id_producto, int cantidad_pieza) {
        mx.edu.itspa.servicios.DetalleEntregaWebService_Service DESRV = new mx.edu.itspa.servicios.DetalleEntregaWebService_Service();
        mx.edu.itspa.servicios.DetalleEntregaWebService PORT = DESRV.getDetalleEntregaWebServicePort();
        
        return PORT.agregarDetalleEntrega(folio_entrega, id_producto, cantidad_pieza);
    }
    
    public static void main(String[] args) {
        DetalleEntrega_Service DESRV = new DetalleEntrega_Service();
                
        /*List<DetalleEntrega> LDE = DESRV.ListarDetalleFacturaEntrega();
            for(DetalleEntrega D_E : LDE) {
                System.out.println(D_E.getNombreProducto());
            }*/
        
        
        /*List<DetalleEntrega> LDE = DESRV.ListarPorId(1);
            for(DetalleEntrega D_E : LDE) {
                System.out.println(D_E.getNombreProducto());
            }*/        
            
        
        /*String SDE = DESRV.Agregar(2, 5, 5);
        List<DetalleEntrega> LDE = DESRV.ListarDetalleFacturaEntrega();
            for(DetalleEntrega D_E : LDE) {
                System.out.println(D_E.getNombreProducto());
            }*/                         
    }
    
}
