package mx.edu.itspa.modelo;

import java.util.List;
import mx.edu.itspa.general.DetalleEntrega;

public interface DetalleEntregaCRUD {
    
    public List ListarDetalleFacturaEntrega();
    public List ListarPorId(int folio_entrega);
    public String Agregar(int folio_entrega, int id_producto, int cantidad_pieza);
    
}
