package mx.edu.itspa.modelo;

import java.util.List;

public interface DetalleVentaCRUD {
    
    public List ListarDetalleFacturaVenta();
    public List ListarPorId(int folio_venta);
    public String Agregar(int folio_venta, int id_producto, int cantidad_pieza);
    
}
