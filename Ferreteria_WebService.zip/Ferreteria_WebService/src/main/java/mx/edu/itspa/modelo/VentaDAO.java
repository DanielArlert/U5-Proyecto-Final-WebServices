package mx.edu.itspa.modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import mx.edu.itspa.general.Conexion;
import mx.edu.itspa.general.Venta;

public class VentaDAO implements VentaCRUD{
    Conexion conexion = new Conexion();
    Connection C = null;
    PreparedStatement ps;
    ResultSet rs;

    @Override
    public List ListarVentas() {
        String SELECT_ALL_VENTA = "select * from FacturaVentas";            
        List<Venta> lista_venta = new ArrayList();
        
        try{
            C = conexion.Conectar();
            ps = C.prepareStatement(SELECT_ALL_VENTA);
            rs = ps.executeQuery();
                Venta venta;
            
            while(rs.next()){
                venta = new Venta();
                
                venta.setFolio_venta(rs.getInt(1));
                venta.setId_cliente(rs.getInt(2));
                venta.setNombre_cliente(rs.getString(3));
                venta.setApellidop_cliente(rs.getString(4));
                venta.setApellidom_cliente(rs.getString(5));
                venta.setTotal(rs.getDouble(6));
                venta.setFecha(rs.getString(7));
                  
                lista_venta.add(venta);
            }            
            
        } catch (Exception e){ }
        
        
        return lista_venta;
    }

    @Override
    public int ProximaFacturaVenta() {
        String SELECT_SIG_VENTA = "select * from FolioVentaSiguiente";
            
        Venta venta = new Venta();
        
        try{
            C = conexion.Conectar();
            ps = C.prepareStatement(SELECT_SIG_VENTA);
            rs = ps.executeQuery();
            
            while(rs.next()){
                venta.setFolio_venta(rs.getInt(1));

                ps.executeUpdate();                
            }            
            
        } catch (Exception e){ }
        
        return venta.getFolio_venta();
    }

    @Override
    public Venta ListarVentasPorId(int folio_venta) {
        String SELECT_FOLIO_ID = "select * from FacturaVentas where folio_venta=" + folio_venta;        
            Venta venta = new Venta();
        
        try{ 
            C = conexion.Conectar();
            ps = C.prepareStatement(SELECT_FOLIO_ID);
            rs = ps.executeQuery();
                
            while(rs.next()){ 
        
                venta.setFolio_venta(rs.getInt(1));
                venta.setId_cliente(rs.getInt(2));
                venta.setNombre_cliente(rs.getString(3));
                venta.setApellidop_cliente(rs.getString(4));
                venta.setApellidom_cliente(rs.getString(5));
                venta.setTotal(rs.getDouble(6));
                venta.setFecha(rs.getString(7));   
                
                    ps.executeUpdate();
            }
                
        } catch(Exception e){ }
        
        return venta;
    }

    @Override
    public String Agregar(int folio_venta, int id_cliente) {
        String INSERT_VENTA = "insert into venta(folio_venta, id_cliente) values(?, ?)";        
            Venta venta = new Venta();
        
        try{
            C = conexion.Conectar();
            ps = C.prepareStatement(INSERT_VENTA);
            
            ps.setInt(1, folio_venta);
            ps.setInt(2, id_cliente);
            
                int res = ps.executeUpdate();
                
                if (res == 1) {
                    return "Venta agregada.";
                } else {
                    return "Error.";
                }
        } catch (NumberFormatException | SQLException e){  
            return "Error: " + e;
        }
        
    }
    
}
