package mx.edu.itspa.modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import mx.edu.itspa.general.Conexion;
import mx.edu.itspa.general.Entrega;

public class EntregaDAO implements EntregaCRUD{
    Conexion conexion = new Conexion();
    Connection C = null;
    PreparedStatement ps;
    ResultSet rs;

    @Override
    public List ListarEntregas() {
        String SELECT_ALL_ENTREGA = "select * from FacturaEntregas";            
        List<Entrega> lista_entrega = new ArrayList();
        
        try{
            C = conexion.Conectar();
            ps = C.prepareStatement(SELECT_ALL_ENTREGA);
            rs = ps.executeQuery();
                Entrega entrega;
            
            while(rs.next()){
                entrega = new Entrega();
                
                entrega.setFolio_entrega(rs.getInt(1));
                entrega.setId_proveedor(rs.getInt(2));
                entrega.setNombre_proveedor(rs.getString(3));
                entrega.setApellidop_proveedor(rs.getString(4));
                entrega.setApellidom_proveedor(rs.getString(5));
                entrega.setTotal(rs.getDouble(6));
                entrega.setFecha(rs.getString(7));
                  
                lista_entrega.add(entrega);
            }            
            
        } catch (Exception e){ }
        
        
        return lista_entrega;
    }

    @Override
    public int ProximaFacturaEntrega() {
        String SELECT_SIG_ENTREGA = "select * from FolioEntregaSiguiente";
            
        Entrega entrega = new Entrega();
        
        try{
            C = conexion.Conectar();
            ps = C.prepareStatement(SELECT_SIG_ENTREGA);
            rs = ps.executeQuery();
            
            while(rs.next()){
                entrega.setFolio_entrega(rs.getInt(1));

                ps.executeUpdate();                
            }            
            
        } catch (Exception e){ }
        
        return entrega.getFolio_entrega();
    }

    @Override
    public Entrega ListarEntregasPorId(int folio_entrega) {
        String SELECT_FOLIO_ID = "select * from FacturaEntregas where folio_entrega=" + folio_entrega;        
            Entrega entrega = new Entrega();
        
        try{ 
            C = conexion.Conectar();
            ps = C.prepareStatement(SELECT_FOLIO_ID);
            rs = ps.executeQuery();
                
            while(rs.next()){ 
        
                entrega.setFolio_entrega(rs.getInt(1));
                entrega.setId_proveedor(rs.getInt(2));
                entrega.setNombre_proveedor(rs.getString(3));
                entrega.setApellidop_proveedor(rs.getString(4));
                entrega.setApellidom_proveedor(rs.getString(5));
                entrega.setTotal(rs.getDouble(6));
                entrega.setFecha(rs.getString(7));   
                
                    ps.executeUpdate();
            }
                
        } catch(Exception e){ }
        
        return entrega;
    }
    
    @Override
    public String Agregar(int folio_entrega, int id_proveedor) {
        String INSERT_ENTREGA = "insert into entrega(folio_entrega, id_proveedor) values(?, ?)";        
            Entrega entrega = new Entrega();
        
        try{
            C = conexion.Conectar();
            ps = C.prepareStatement(INSERT_ENTREGA);
            
            ps.setInt(1, folio_entrega);
            ps.setInt(2, id_proveedor);
            
                int res = ps.executeUpdate();
                
                if (res == 1) {
                    return "Entrega agregads.";
                } else {
                    return "Error.";
                }
        } catch (NumberFormatException | SQLException e){  
            return "Error: " + e;
        }
        
    }
    
}
