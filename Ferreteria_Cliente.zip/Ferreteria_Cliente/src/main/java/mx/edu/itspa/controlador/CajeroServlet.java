package mx.edu.itspa.controlador;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import mx.edu.itspa.modelo.Cliente_Service;
import mx.edu.itspa.modelo.DetalleVenta_Service;
import mx.edu.itspa.modelo.Producto_Service;
import mx.edu.itspa.modelo.Venta_Service;
import mx.edu.itspa.servicios.Cliente;
import mx.edu.itspa.servicios.DetalleVenta;
import mx.edu.itspa.servicios.Producto;
import mx.edu.itspa.servicios.Venta;

public class CajeroServlet extends HttpServlet {

    Producto producto = new Producto();
    Producto_Service PDAO = new Producto_Service();
    int id_producto;

    Cliente_Service CLSRV = new Cliente_Service();
    Cliente CLI = new Cliente();
    int id_cliente;
    
    Venta venta = new Venta();
    Venta_Service VSRV = new Venta_Service();
    
    int folio_venta;
    DetalleVenta d_venta = new DetalleVenta();
    DetalleVenta_Service DVSRV = new DetalleVenta_Service();

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        String menu = request.getParameter("menu");
        
            if(menu.equals("Cajero")){
                List listado = VSRV.ListarVentas();
                request.setAttribute("facturaventa", listado);
                
                request.getRequestDispatcher("Vista/Cajero/Cajero.jsp").forward(request, response);
            }
            
            if(menu.equals("CajeroObtenerDetalle")){
                folio_venta = Integer.parseInt(request.getParameter("folio_venta"));
                List DV = DVSRV.ListarPorId(folio_venta);
                
                request.setAttribute("detallefacturaventa", DV);
                request.getRequestDispatcher("CajeroServlet?menu=Cajero").forward(request, response);
            } 
            
            
            
            
            
            if(menu.equals("CajeroSelectClientes")){
                Cliente_Service CL = new Cliente_Service();
                List<Cliente> SelectAllCliente = CL.SelectAllCliente();
                request.setAttribute("clientes", SelectAllCliente);
                
                request.getRequestDispatcher("Vista/Cajero/Clientes.jsp").forward(request, response);
            } 
            
            if(menu.equals("CajeroInsertClientes")){
                String nc = request.getParameter("nombre_cliente");
                String appc = request.getParameter("apellidop_cliente");
                String apmc = request.getParameter("apellidom_cliente");
                String c = request.getParameter("calle");
                String n = request.getParameter("numero");
                String cd = request.getParameter("ciudad");
                String t = request.getParameter("telefono");

                    CLSRV.InsertCliente(nc, appc, apmc, c, n, cd, t);
                    request.getRequestDispatcher("CajeroServlet?menu=CajeroSelectClientes").forward(request, response);
            }

            if(menu.equals("CajeroIdentifierClientes")){
                int id_cliente = Integer.parseInt(request.getParameter("id_cliente")); 
                    request.setAttribute("idcli", id_cliente);

                    Cliente_Service CLSRV = new Cliente_Service();
                    Cliente CLI = CLSRV.SelectClienteId(id_cliente);

                    String incl = CLI.getNombreCliente();
                    String iapcl = CLI.getApellidopCliente();
                    String iamcl = CLI.getApellidomCliente();
                    String ca = CLI.getCalle();
                    String num = CLI.getNumero();
                    String cd = CLI.getCiudad();
                    String tel = CLI.getTelefono();

                    request.setAttribute("incl", incl);
                    request.setAttribute("iapcl", iapcl);
                    request.setAttribute("iamcl", iamcl);
                    request.setAttribute("ca", ca);
                    request.setAttribute("num", num);
                    request.setAttribute("cd", cd);
                    request.setAttribute("tel", tel);

                    request.getRequestDispatcher("CajeroServlet?menu=CajeroSelectClientes").forward(request, response);
            }                      

            if(menu.equals("CajeroUpdateClientes")){
                int idcl = Integer.parseInt(request.getParameter("id_cliente"));
                String nc = request.getParameter("nombre_cliente");
                String appc = request.getParameter("apellidop_cliente");
                String apmc = request.getParameter("apellidom_cliente");
                String c = request.getParameter("calle");
                String n = request.getParameter("numero");
                String cd = request.getParameter("ciudad");
                String t = request.getParameter("telefono");

                    CLSRV.UpdateCliente(idcl, nc, appc, apmc, c, n, cd, t);

                    request.getRequestDispatcher("CajeroServlet?menu=CajeroSelectClientes").forward(request, response);
            }  
            
            if(menu.equals("CajeroDeleteClientes")){
                int idcliente = Integer.parseInt(request.getParameter("id_cliente")); 

                    Cliente_Service CLSRV = new Cliente_Service();
                    Cliente CLI = CLSRV.DeleteCliente(idcliente);

                    request.getRequestDispatcher("CajeroServlet?menu=CajeroSelectClientes").forward(request, response);
            }  
            
            
            
            
            
            if(menu.equals("CajeroSelectProductos")){
                Producto_Service PDT = new Producto_Service();
                List<Producto> SelectAllProducto = PDT.SelectAllProducto();
                request.setAttribute("productos", SelectAllProducto);
                
                request.getRequestDispatcher("Vista/Cajero/Productos.jsp").forward(request, response);
            } 
            
            
            
            
            
            if(menu.equals("CajeroFacturarVenta")){
                int next_v = VSRV.ProximaFacturaVenta();                    
                request.setAttribute("prx", next_v);
                
                request.getRequestDispatcher("Vista/Cajero/FacturarVenta.jsp").forward(request, response);
            } 
            
                if(menu.equals("CajeroFacturarVentaIdProducto")){
                    id_producto=Integer.parseInt(request.getParameter("id_producto"));
                    Producto P = PDAO.SelectProductoId(id_producto);
                    request.setAttribute("pfv", P);
                    
                    request.getRequestDispatcher("CajeroServlet?menu=CajeroFacturarVenta").forward(request, response);
                } 

                if(menu.equals("CajeroFacturarVentaIdCliente")){
                    id_cliente=Integer.parseInt(request.getParameter("id_cliente"));
                    Cliente C = CLSRV.SelectClienteId(id_cliente);

                    request.setAttribute("cfv", C);
                    request.getRequestDispatcher("CajeroServlet?menu=CajeroFacturarVenta").forward(request, response);
                } 
            
                if(menu.equals("CajeroFacturaVentaIngresarProducto")){
                    int fv = Integer.parseInt(request.getParameter("folio_venta"));
                    int ip = Integer.parseInt(request.getParameter("id_producto"));
                    int can = Integer.parseInt(request.getParameter("cantidad_pieza"));
                    
                    DVSRV.Agregar(fv, ip, can);
                    request.getRequestDispatcher("CajeroServlet?menu=CajeroFacturarVenta").forward(request, response);
                } 
            
                if(menu.equals("CajeroFacturar")){
                    int fvf = Integer.parseInt(request.getParameter("folio_venta"));
                    int icf = Integer.parseInt(request.getParameter("id_cliente")); 
                    
                        VSRV.Agregar(fvf, icf);
                    
                    request.getRequestDispatcher("CajeroServlet?menu=CajeroComprobante").forward(request, response);
                } 
            
                if(menu.equals("CajeroComprobante")){
                    int fvf = Integer.parseInt(request.getParameter("folio_venta"));    
                    int icf = Integer.parseInt(request.getParameter("id_cliente"));  
                    
                    int x = fvf;
                        List DV = DVSRV.ListarPorId(x);
                        request.setAttribute("DV", DV);
                        request.setAttribute("folio", x);                                             
                        
                    Venta propietario = VSRV.SelectVentaId(fvf);
                    request.setAttribute("p_ven", propietario);
                                        
                    Cliente CLI = CLSRV.SelectClienteId(icf);
                    request.setAttribute("c", CLI);
                
                request.getRequestDispatcher("Vista/Cajero/CFactura.jsp").forward(request, response);
                }        
            
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
