package mx.edu.itspa.modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import mx.edu.itspa.general.Conexion;
import mx.edu.itspa.general.Usuario;

public class UsuarioDAO implements UsuarioR{
    
    Conexion conexion = new Conexion();
    Connection C = null;
    Usuario US = new Usuario();
    PreparedStatement ps;
    ResultSet rs;
    int res;    

    @Override
    public Usuario Validar(String usuario, String clave) {
        String SELECT_USER = "select r.id_rol, r.nombre_rol, us.usuario, us.clave from usuario us inner join rol r on r.id_rol = us.id_rol where us.usuario=? and us.clave=?";
        
        try{
            C = conexion.Conectar();
            ps = C.prepareStatement(SELECT_USER);
            
                ps.setString(1, usuario);
                ps.setString(2, clave);            
                rs = ps.executeQuery();
            
            while (rs.next()) {
                US.setId_rol(rs.getInt("id_rol"));
                US.setNombre_rol(rs.getString("nombre_rol"));
                US.setUsuario(rs.getString("usuario"));
                US.setClave(rs.getString("clave"));
                
                //System.out.println(US.getNombre_rol());
            }
            
            C.close();
            
        }catch(Exception e){    }
        
        return US;
    }
    
}
