package mx.edu.itspa.modelo;

import java.util.List;
import mx.edu.itspa.servicios.Producto;

public class Producto_Service {
    
    public Producto_Service() { }
    
    
    public java.util.List<mx.edu.itspa.servicios.Producto> SelectAllProducto(){
        mx.edu.itspa.servicios.ProductoWebService_Service PSRV = new mx.edu.itspa.servicios.ProductoWebService_Service();
        mx.edu.itspa.servicios.ProductoWebService PORT = PSRV.getProductoWebServicePort();
        
        return PORT.selectAllProducto();
    }
        
    
    public String InsertProducto(java.lang.String nombre_producto, int precio_compra, int precio_venta, java.lang.String marca, int stock, java.lang.String medidas){
        mx.edu.itspa.servicios.ProductoWebService_Service PSRV = new mx.edu.itspa.servicios.ProductoWebService_Service();
        mx.edu.itspa.servicios.ProductoWebService PORT = PSRV.getProductoWebServicePort();
        
        return PORT.insertProducto(nombre_producto, precio_compra, precio_venta, marca, stock, medidas);
    }
    
    
    public Producto SelectProductoId(int id_producto){
        mx.edu.itspa.servicios.ProductoWebService_Service PSRV = new mx.edu.itspa.servicios.ProductoWebService_Service();
        mx.edu.itspa.servicios.ProductoWebService PORT = PSRV.getProductoWebServicePort();
        
        return PORT.selectProductoId(id_producto);
    }
        
    
    public String UpdateProducto(int id_producto, java.lang.String nombre_producto, int precio_compra, int precio_venta, java.lang.String marca, int stock, java.lang.String medidas){
        mx.edu.itspa.servicios.ProductoWebService_Service PSRV = new mx.edu.itspa.servicios.ProductoWebService_Service();
        mx.edu.itspa.servicios.ProductoWebService PORT = PSRV.getProductoWebServicePort();
        
        return PORT.updateProducto(id_producto, nombre_producto, precio_compra, precio_venta, marca, stock, medidas);
    }    
    

    public Producto DeleteProducto(int id_producto){
        mx.edu.itspa.servicios.ProductoWebService_Service PSRV = new mx.edu.itspa.servicios.ProductoWebService_Service();
        mx.edu.itspa.servicios.ProductoWebService PORT = PSRV.getProductoWebServicePort();
        
        return PORT.deleteProducto(id_producto);
    }  
    
    public static void main(String[] args) {
        Producto_Service PSRV = new Producto_Service();
        
        //System.out.println("Producto");    
        
        /*List PR = PSRV.SelectAllProducto();
        System.out.println(PR.size());*/
        
        
        //String IP = PSRV.InsertProducto("Mjolnir", 150, 150, "Marvel", 500, "150");
                
        
        /*Producto P = PSRV.SelectProductoId(11);
            System.out.println(P.getIdProducto() + " " + P.getNombreProducto());*/
            
        
        /*String UP = PSRV.UpdateProducto(10, "Reactor Stark", 150, 150, "Marvel", 500, "150");
        Producto P = PSRV.SelectProductoId(10);
            System.out.println(P.getIdProducto() + " " + P.getNombreProducto());*/
       
        
       /*Producto DP = PSRV.DeleteProducto(9);
       List PR = PSRV.SelectAllProducto();
        System.out.println(PR.size());*/       
    }
    
}
