package mx.edu.itspa.modelo;

import java.util.List;
import mx.edu.itspa.general.Cliente;

public interface ClienteCRUD {
    
    public List SelectAllCliente();
    public Cliente SelectClienteId(int id_cliente);
    public String InsertCliente(String nombre_cliente, String apellidop_cliente, String apellidom_cliente, String calle, String numero, String ciudad, String telefono);
    public String UpdateCliente(int id_cliente, String nombre_producto, String apellidop_cliente, String apellidom_cliente, String calle, String numero, String ciudad, String telefono);
    public Cliente DeleteCliente(int id_cliente);
    
}
