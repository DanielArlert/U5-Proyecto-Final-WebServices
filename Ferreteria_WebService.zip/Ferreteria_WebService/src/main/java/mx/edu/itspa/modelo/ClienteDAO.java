package mx.edu.itspa.modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import mx.edu.itspa.general.Cliente;
import mx.edu.itspa.general.Conexion;

public class ClienteDAO implements ClienteCRUD{
    
    Conexion conexion = new Conexion();
    Connection C = null;
    Cliente CID = new Cliente();
    PreparedStatement ps;
    ResultSet rs;
    int res;    

    @Override
    public List SelectAllCliente() {
        String SELECT_ALL_CLIENTE = "select * from cliente";
            List<Cliente> lista_cliente = new ArrayList<>();
            
        try{
            C = conexion.Conectar();
            ps = C.prepareStatement(SELECT_ALL_CLIENTE);
            rs = ps.executeQuery();
                Cliente cli;
            
            while(rs.next()){
                cli = new Cliente(
                    Integer.parseInt(rs.getString(1)), 
                        rs.getString(2), rs.getString(3), rs.getString(4), 
                        rs.getString(5), rs.getString(6), rs.getString(7), 
                        rs.getString(8)
                );
                
                  
                lista_cliente.add(cli);
            } 
            
            C.close();
            
        } catch (NumberFormatException | SQLException e){  
            System.out.println("Error: " + e);
        }
        
        return lista_cliente;    
    }

    
    @Override
    public Cliente SelectClienteId(int id_cliente) {
        String SELECT_CLIENTE_ID = "select * from cliente where id_cliente=" + id_cliente;
                        
        try{
            C = conexion.Conectar();
            ps = C.prepareStatement(SELECT_CLIENTE_ID);
            rs = ps.executeQuery();
            
            while(rs.next()){
                CID.setId_cliente(rs.getInt("id_cliente"));
                CID.setNombre_cliente(rs.getString("nombre_cliente"));    
                CID.setApellidop_cliente(rs.getString("apellidop_cliente"));  
                CID.setApellidom_cliente(rs.getString("apellidom_cliente"));  
                CID.setCalle(rs.getString("calle"));      
                CID.setNumero(rs.getString("numero"));   
                CID.setCiudad(rs.getString("ciudad"));    
                CID.setTelefono(rs.getString("telefono"));       
            } 
            
            C.close();
            
        } catch (NumberFormatException | SQLException e){  
            System.out.println("Error: " + e);
        }
        
        return CID;     
    }

    
    @Override
    public String InsertCliente(String nombre_cliente, String apellidop_cliente, String apellidom_cliente, String calle, String numero, String ciudad, String telefono) {
        String INSERT_CLIENTE = "insert into cliente(nombre_cliente, apellidop_cliente, apellidom_cliente, calle, numero, ciudad, telefono) values(?, ?, ?, ?, ?, ?, ?)";
        
        try{
            C = conexion.Conectar();
            ps = C.prepareStatement(INSERT_CLIENTE);
            
            ps.setString(1, nombre_cliente);
            ps.setString(2, apellidop_cliente);
            ps.setString(3, apellidom_cliente);
            ps.setString(4, calle);
            ps.setString(5, numero);
            ps.setString(6, ciudad);
            ps.setString(7, telefono);
                res = ps.executeUpdate();
                
                if (res == 1) {
                    return "Cliente agregado.";
                } else {
                    return "Error.";
                }
        } catch (NumberFormatException | SQLException e){  
            return "Error: " + e;
        }
    }

    
    @Override
    public String UpdateCliente(int id_cliente, String nombre_cliente, String apellidop_cliente, String apellidom_cliente, String calle, String numero, String ciudad, String telefono) {
        String UPDATE_CLIENTE = "update cliente set nombre_cliente=?, apellidop_cliente=?, apellidom_cliente=?, calle=?, numero=?, ciudad=?, telefono=? where id_cliente=" + id_cliente;
        
        try{
            C = conexion.Conectar();
            ps = C.prepareStatement(UPDATE_CLIENTE);
            
            ps.setString(1, nombre_cliente);
            ps.setString(2, apellidop_cliente);
            ps.setString(3, apellidom_cliente);
            ps.setString(4, calle);
            ps.setString(5, numero);
            ps.setString(6, ciudad);
            ps.setString(7, telefono);
                res = ps.executeUpdate();
                
                if (res == 1) {
                    return "Cliente agregado.";
                } else {
                    return "Error.";
                }
        } catch (NumberFormatException | SQLException e){  
            return "Error: " + e;
        }
    }

    
    @Override
    public Cliente DeleteCliente(int id_cliente) {
        String DELETE_CLIENTE = "delete from cliente where id_cliente="+id_cliente;
        
        try{
            C = conexion.Conectar();
            ps = C.prepareStatement(DELETE_CLIENTE);
                res = ps.executeUpdate();
        } catch (NumberFormatException | SQLException e){  
            System.out.println("Error: " + e);
        }
          
        return CID;  
    }
    
}
