package mx.edu.itspa.servicios;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import mx.edu.itspa.general.Usuario;
import mx.edu.itspa.modelo.UsuarioDAO;

@WebService(serviceName = "UsuarioWebService")
public class UsuarioWebService {
    
    UsuarioDAO USDAO = new UsuarioDAO();

    @WebMethod(operationName = "Validar")
    public Usuario Validar(@WebParam(name="usuario") String usuario, @WebParam(name="clave") String clave){
        Usuario US = USDAO.Validar(usuario, clave);
        
        return US;
    }
}
