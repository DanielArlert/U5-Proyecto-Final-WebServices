package mx.edu.itspa.controlador;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import mx.edu.itspa.modelo.DetalleEntrega_Service;
import mx.edu.itspa.modelo.Entrega_Service;
import mx.edu.itspa.modelo.Producto_Service;
import mx.edu.itspa.modelo.Proveedor_Service;
import mx.edu.itspa.servicios.DetalleEntrega;
import mx.edu.itspa.servicios.Entrega;
import mx.edu.itspa.servicios.Producto;
import mx.edu.itspa.servicios.Proveedor;

public class AlmacenistaServlet extends HttpServlet {

    Producto_Service PSRV = new Producto_Service();
    Producto P = new Producto();
    int id_producto;
    
    Proveedor_Service PROSRV = new Proveedor_Service();
    Proveedor PROV = new Proveedor();
    int id_proveedor;
    
    int folio_entrega;
    Entrega entrega = new Entrega();
    Entrega_Service ESRV = new Entrega_Service();
    
    DetalleEntrega d_entrega = new DetalleEntrega();
    DetalleEntrega_Service DESRV = new DetalleEntrega_Service();

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        String menu = request.getParameter("menu");
        
            if(menu.equals("Almacenista")){
                List listado = ESRV.ListarEntregas();
                request.setAttribute("facturaentrega", listado);
                
                request.getRequestDispatcher("Vista/Almacenista/Almacenista.jsp").forward(request, response);
            } 
        
            if(menu.equals("AlmacenistaObtenerDetalle")){
                folio_entrega = Integer.parseInt(request.getParameter("folio_entrega"));
                List DE = DESRV.ListarPorId(folio_entrega);                
                request.setAttribute("detallefacturaentrega", DE);
                
                request.getRequestDispatcher("AlmacenistaServlet?menu=Almacenista").forward(request, response);
            }         
            
            
            
            
            
            if(menu.equals("AlmacenistaSelectProveedores")){
                Proveedor_Service PRO= new Proveedor_Service();
                List<Proveedor> SelectAllProveedor = PRO.SelectAllProveedor();
                request.setAttribute("proveedores", SelectAllProveedor);
                
                request.getRequestDispatcher("Vista/Almacenista/Proveedores.jsp").forward(request, response);
            } 
            
            if(menu.equals("AlmacenistaInsertProveedores")){
                String npro = request.getParameter("nombre_proveedor");
                String appro = request.getParameter("apellidop_proveedor");
                String ampro = request.getParameter("apellidom_proveedor");
                String c = request.getParameter("correo");

                    PROSRV.InsertProveedor(npro, appro, ampro, c);
                    request.getRequestDispatcher("AlmacenistaServlet?menu=AlmacenistaSelectProveedores").forward(request, response);
            }

            if(menu.equals("AlmacenistaIdentifierProveedores")){
                int id_proveedor = Integer.parseInt(request.getParameter("id_proveedor")); 
                    request.setAttribute("idpro", id_proveedor);

                    Proveedor_Service PROSRV = new Proveedor_Service();
                    Proveedor PROV = PROSRV.SelectProveedorId(id_proveedor);

                    String inpro = PROV.getNombreProveedor();
                    String iappro = PROV.getApellidopProveedor();
                    String iampro = PROV.getApellidomProveedor();
                    String c = PROV.getCorreo();

                    request.setAttribute("inpro", inpro);
                    request.setAttribute("iappro", iappro);
                    request.setAttribute("iampro", iampro);
                    request.setAttribute("c", c);

                    request.getRequestDispatcher("AlmacenistaServlet?menu=AlmacenistaSelectProveedores").forward(request, response);
            }

            if(menu.equals("AlmacenistaUpdateProveedores")){
                int idpro = Integer.parseInt(request.getParameter("id_proveedor"));
                String npro = request.getParameter("nombre_proveedor");
                String appro = request.getParameter("apellidop_proveedor");
                String ampro = request.getParameter("apellidom_proveedor");
                String c = request.getParameter("correo");

                    PROSRV.UpdateProveedor(idpro, npro, appro, ampro, c);

                    request.getRequestDispatcher("AlmacenistaServlet?menu=AlmacenistaSelectProveedores").forward(request, response);
            }

            if(menu.equals("AlmacenistaDeleteProveedores")){
                int idproveedoor = Integer.parseInt(request.getParameter("id_proveedor")); 

                    Proveedor_Service PROSRV = new Proveedor_Service();
                    Proveedor PROV = PROSRV.DeleteProveedor(idproveedoor);

                    request.getRequestDispatcher("AlmacenistaServlet?menu=AlmacenistaSelectProveedores").forward(request, response);
            }
            
             
            
            
            
            if(menu.equals("AlmacenistaSelectProductos")){
                Producto_Service PDT = new Producto_Service();
                List<Producto> SelectAllProducto = PDT.SelectAllProducto();
                request.setAttribute("productos", SelectAllProducto);
                
                request.getRequestDispatcher("Vista/Almacenista/Productos.jsp").forward(request, response);
            } 
            
            if(menu.equals("AlmacenistaInsertProductos")){
                String np = request.getParameter("nombre_producto");
                int pc = Integer.parseInt(request.getParameter("precio_compra"));
                int pv = Integer.parseInt(request.getParameter("precio_venta"));
                String mrc = request.getParameter("marca");
                int stk = Integer.parseInt(request.getParameter("stock"));
                String mds = request.getParameter("medidas");

                    PSRV.InsertProducto(np, pc, pv, mrc, stk, mds);
                    request.getRequestDispatcher("AlmacenistaServlet?menu=AlmacenistaSelectProductos").forward(request, response);
            }

            if(menu.equals("AlmacenistaIdentifierProductos")){
                int id_producto = Integer.parseInt(request.getParameter("id_producto")); 
                    request.setAttribute("idp", id_producto);

                    Producto_Service PSRV = new Producto_Service();
                    Producto P = PSRV.SelectProductoId(id_producto);

                    String inp = P.getNombreProducto();
                    int ipc = P.getPrecioCompra();
                    int ipv = P.getPrecioVenta();
                    String imrc = P.getMarca();
                    int istk = P.getStock();
                    String imds = P.getMedidas();

                    request.setAttribute("inp", inp);
                    request.setAttribute("ipc", ipc);
                    request.setAttribute("ipv", ipv);
                    request.setAttribute("imrc", imrc);
                    request.setAttribute("istk", istk);
                    request.setAttribute("imds", imds);

                    request.getRequestDispatcher("AlmacenistaServlet?menu=AlmacenistaSelectProductos").forward(request, response);
            }

            if(menu.equals("AlmacenistaUpdateProductos")){
                int idp = Integer.parseInt(request.getParameter("id_producto"));
                String np = request.getParameter("nombre_producto");
                int pc = Integer.parseInt(request.getParameter("precio_compra"));
                int pv = Integer.parseInt(request.getParameter("precio_venta"));
                String mrc = request.getParameter("marca");
                int stk = Integer.parseInt(request.getParameter("stock"));
                String mds = request.getParameter("medidas");

                    PSRV.UpdateProducto(idp, np, pc, pv, mrc, stk, mds);

                    request.getRequestDispatcher("AlmacenistaServlet?menu=AlmacenistaSelectProductos").forward(request, response);
            }

            if(menu.equals("AlmacenistaDeleteProductos")){
                int id_productoo = Integer.parseInt(request.getParameter("id_producto")); 
                
                    Producto_Service PSRV = new Producto_Service();
                    Producto PX = PSRV.DeleteProducto(id_productoo);

                    request.getRequestDispatcher("AlmacenistaServlet?menu=AlmacenistaSelectProductos").forward(request, response);
            }
            
            
            
            
            
            if(menu.equals("AlmacenistaFacturarEntrega")){
                int next_e = ESRV.ProximaFacturaEntrega();
                request.setAttribute("prx", next_e);
                
                request.getRequestDispatcher("Vista/Almacenista/FacturarEntrega.jsp").forward(request, response);
            } 
            
                if(menu.equals("AlmacenistaFacturarEntregaIdProducto")){
                    id_producto=Integer.parseInt(request.getParameter("id_producto"));
                    Producto P = PSRV.SelectProductoId(id_producto);
                    request.setAttribute("pfe", P);
                    
                    request.getRequestDispatcher("AlmacenistaServlet?menu=AlmacenistaFacturarEntrega").forward(request, response);
                } 

                if(menu.equals("AlmacenistaFacturarEntregaIdProveedor")){
                    id_proveedor=Integer.parseInt(request.getParameter("id_proveedor"));
                    Proveedor P = PROSRV.SelectProveedorId(id_proveedor);
                    request.setAttribute("prfe", P);
                    
                    request.getRequestDispatcher("AlmacenistaServlet?menu=AlmacenistaFacturarEntrega").forward(request, response);
                } 
            
                if(menu.equals("AlmacenistaFacturarEntregaIngresarProducto")){
                    int fe = Integer.parseInt(request.getParameter("folio_entrega"));
                    int ip = Integer.parseInt(request.getParameter("id_producto"));
                    int can = Integer.parseInt(request.getParameter("cantidad_pieza"));
                                        
                    DESRV.Agregar(fe, ip, can);
                    
                    request.getRequestDispatcher("AlmacenistaServlet?menu=AlmacenistaFacturarEntrega").forward(request, response);
                } 
            
                if(menu.equals("AlmacenistaFacturar")){
                    int fef = Integer.parseInt(request.getParameter("folio_entrega"));
                    int ipf = Integer.parseInt(request.getParameter("id_proveedor"));
                    
                    ESRV.Agregar(fef, ipf);
                
                    request.getRequestDispatcher("AlmacenistaServlet?menu=AlmacenistaComprobante").forward(request, response);
                } 
            
                if(menu.equals("AlmacenistaComprobante")){
                    int fef = Integer.parseInt(request.getParameter("folio_entrega"));     
                    int ipf = Integer.parseInt(request.getParameter("id_proveedor"));   
                        
                    int x = fef;
                        List DE = DESRV.ListarPorId(x);
                        request.setAttribute("DE", DE);
                        request.setAttribute("folio", x);
                        
                    Entrega propietario = ESRV.SelectEntregaId(fef);
                    request.setAttribute("p_ent", propietario);
                    
                    Proveedor PRO = PROSRV.SelectProveedorId(ipf);
                    request.setAttribute("pr", PRO);
                
                request.getRequestDispatcher("Vista/Almacenista/AFactura.jsp").forward(request, response);
                } 
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
