package mx.edu.itspa.general;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    private String database = "jdbc:mysql://localhost:3306/FRT?useTimeZone=true&serverTimezone=UTC&autoReconnect=true&useSSL=false";
    private String usuario = "root";
    private String clave = "root";
    
    public Connection Conectar() {
        Connection connection = null;
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                connection = DriverManager.getConnection(database, usuario, clave);
            } catch (ClassNotFoundException | SQLException e) {
            } 
        return connection;
    }
    
}