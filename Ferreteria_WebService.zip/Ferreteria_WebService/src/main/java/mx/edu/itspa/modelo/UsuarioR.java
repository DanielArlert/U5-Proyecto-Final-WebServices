package mx.edu.itspa.modelo;

import mx.edu.itspa.general.Usuario;

public interface UsuarioR {
    
    public Usuario Validar(String usuario, String clave);
    
}
