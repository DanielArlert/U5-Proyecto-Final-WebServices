package mx.edu.itspa.modelo;

import java.util.List;
import mx.edu.itspa.general.Entrega;

public interface EntregaCRUD {
    
    public List ListarEntregas();
    public int ProximaFacturaEntrega();
    public Entrega ListarEntregasPorId(int folio_entrega);
    public String Agregar(int folio_entrega, int id_proveedor);
    
}
