package mx.edu.itspa.servicios;

import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import mx.edu.itspa.general.Proveedor;
import mx.edu.itspa.modelo.ProveedorDAO;

@WebService(serviceName = "ProveedorWebService")
public class ProveedorWebService {

    ProveedorDAO PRODAO = new ProveedorDAO();   
        
    @WebMethod(operationName = "SelectAllProveedor")
    public List<Proveedor> SelectAllProveedor() {
        List ListadoProveedores = PRODAO.SelectAllProveedor();
        
        return ListadoProveedores;
    }
    
    

    @WebMethod(operationName = "InsertProveedor")
    public String InsertProveedor(
            @WebParam(name = "nombre_proveedor") String nombre_proveedor,
            @WebParam(name = "apellidop_proveedor") String apellidop_proveedor,
            @WebParam(name = "apellidom_proveedor") String apellidom_proveedor,
            @WebParam(name = "correo") String correo
    ) {
        
        String consulta = PRODAO.InsertProveedor(nombre_proveedor, apellidop_proveedor, apellidom_proveedor, correo);
        
        return consulta;
    }
    
    

    @WebMethod(operationName = "SelectProveedorId")
    public Proveedor SelectProveedorId(@WebParam(name="id_proveedor") int id_proveedor){
        Proveedor PRO = PRODAO.SelectProveedorId(id_proveedor);
        
        return PRO;
    }
    
    

    @WebMethod(operationName = "UpdateProveedor")
    public String updateProveedor(
            @WebParam(name = "id_proveedor") int id_proveedor,
            @WebParam(name = "nombre_proveedor") String nombre_proveedor,
            @WebParam(name = "apellidop_proveedor") String apellidop_proveedor,
            @WebParam(name = "apellidom_proveedor") String apellidom_proveedor,
            @WebParam(name = "correo") String correo
    ) {
        
        String consulta = PRODAO.UpdateProveedor(id_proveedor, nombre_proveedor, apellidop_proveedor, apellidom_proveedor, correo);
        
        return consulta;
    }
    
    

    @WebMethod(operationName = "DeleteProveedor")
    public Proveedor DeleteProveedor(@WebParam(name="id_proveedor") int id_proveedor){
        Proveedor PRO = PRODAO.DeleteProveedor(id_proveedor);
        
        return PRO;
    }
    
}
