package mx.edu.itspa.modelo;

import java.util.List;
import mx.edu.itspa.general.Proveedor;

public interface ProveedorCRUD {
    
    public List SelectAllProveedor();
    public Proveedor SelectProveedorId(int id_proveedor);
    public String InsertProveedor(String nombre_proveedor, String apellidop_proveedor, String apellidom_proveedor, String correo);
    public String UpdateProveedor(int id_proveedor, String nombre_proveedor, String apellidop_proveedor, String apellidom_proveedor, String correo);
    public Proveedor DeleteProveedor(int id_proveedor);
    
}
