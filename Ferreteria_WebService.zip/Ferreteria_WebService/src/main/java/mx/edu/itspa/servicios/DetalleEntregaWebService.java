package mx.edu.itspa.servicios;

import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import mx.edu.itspa.general.DetalleEntrega;
import mx.edu.itspa.modelo.DetalleEntregaDAO;

@WebService(serviceName = "DetalleEntregaWebService")
public class DetalleEntregaWebService {

    DetalleEntregaDAO DEDAO = new DetalleEntregaDAO();
        
    @WebMethod(operationName = "ListarDetalleFacturaEntrega")
    public List<DetalleEntrega> ListarDetalleFacturaEntrega(){
        List LDE = DEDAO.ListarDetalleFacturaEntrega();
        
        return LDE;
    }
    

    @WebMethod(operationName = "ListarDetalleEntregaPorId")
    public List<DetalleEntrega> ListarDetalleEntregaPorId(@WebParam(name="folio_entrega") int folio_entrega){
        List LDE = DEDAO.ListarPorId(folio_entrega);
        
        return LDE;
    }
    
    
    @WebMethod(operationName = "AgregarDetalleEntrega")
    public String AgregarDetalleEntrega(
            @WebParam(name = "folio_entrega") int folio_entrega,
            @WebParam(name = "id_producto") int id_producto,
            @WebParam(name = "cantidad_pieza") int cantidad_pieza
    ) {
        
        String consulta = DEDAO.Agregar(folio_entrega, id_producto, cantidad_pieza);
        
        return consulta;
    }   
    
}