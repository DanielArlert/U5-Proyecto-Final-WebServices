package mx.edu.itspa.modelo;

import java.util.List;
import mx.edu.itspa.servicios.Usuario;

public class Usuario_Service {
    
    public Usuario_Service() {    }
    
    public Usuario Validar(String usuario, String clave){
        mx.edu.itspa.servicios.UsuarioWebService_Service USRV = new mx.edu.itspa.servicios.UsuarioWebService_Service();
        mx.edu.itspa.servicios.UsuarioWebService PORT = USRV.getUsuarioWebServicePort();
        
        return PORT.validar(usuario, clave);
    }
    
    public static void main(String[] args) {
        Usuario_Service USRV = new Usuario_Service();
        
        /*Usuario U = USRV.Validar("almacenista", "19092010");
            System.out.println(U.getNombreRol());     */
    }
}
