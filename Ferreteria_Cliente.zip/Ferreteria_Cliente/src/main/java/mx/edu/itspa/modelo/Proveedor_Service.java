package mx.edu.itspa.modelo;

import java.util.List;
import mx.edu.itspa.servicios.Proveedor;

public class Proveedor_Service {
    
    public Proveedor_Service() { }
    
    
    public java.util.List<mx.edu.itspa.servicios.Proveedor> SelectAllProveedor(){
        mx.edu.itspa.servicios.ProveedorWebService_Service PSRV = new mx.edu.itspa.servicios.ProveedorWebService_Service();
        mx.edu.itspa.servicios.ProveedorWebService PORT = PSRV.getProveedorWebServicePort();
        
        return PORT.selectAllProveedor();
    }
        
    
    public String InsertProveedor(java.lang.String nombre_proveedor, java.lang.String apellidop_proveedor, java.lang.String apellidom_proveedor, java.lang.String correo){
        mx.edu.itspa.servicios.ProveedorWebService_Service PSRV = new mx.edu.itspa.servicios.ProveedorWebService_Service();
        mx.edu.itspa.servicios.ProveedorWebService PORT = PSRV.getProveedorWebServicePort();
        
        return PORT.insertProveedor(nombre_proveedor, apellidop_proveedor, apellidom_proveedor, correo);
    }
    
    
    public Proveedor SelectProveedorId(int id_proveedor){
        mx.edu.itspa.servicios.ProveedorWebService_Service PSRV = new mx.edu.itspa.servicios.ProveedorWebService_Service();
        mx.edu.itspa.servicios.ProveedorWebService PORT = PSRV.getProveedorWebServicePort();
        
        return PORT.selectProveedorId(id_proveedor);
    }
        
    
    public String UpdateProveedor(int id_proveedor, java.lang.String nombre_proveedor, java.lang.String apellidop_proveedor, java.lang.String apellidom_proveedor, java.lang.String correo){
        mx.edu.itspa.servicios.ProveedorWebService_Service PSRV = new mx.edu.itspa.servicios.ProveedorWebService_Service();
        mx.edu.itspa.servicios.ProveedorWebService PORT = PSRV.getProveedorWebServicePort();
        
        return PORT.updateProveedor(id_proveedor, nombre_proveedor, apellidop_proveedor, apellidom_proveedor, correo);
    }
    

    public Proveedor DeleteProveedor(int id_proveedor){
        mx.edu.itspa.servicios.ProveedorWebService_Service PSRV = new mx.edu.itspa.servicios.ProveedorWebService_Service();
        mx.edu.itspa.servicios.ProveedorWebService PORT = PSRV.getProveedorWebServicePort();
        
        return PORT.deleteProveedor(id_proveedor);
    }  
    
    public static void main(String[] args) {
        Proveedor_Service CLSRV = new Proveedor_Service();
        
        //System.out.println("Producto");    
        
        /*List PR = CLSRV.SelectAllProveedor();
        System.out.println(PR.size());*/
        
        
        //String IP = CLSRV.InsertProveedor("1", "1", "1", "1", "1", "1", "1");
                
        
        /*Proveedor P = CLSRV.SelectProveedorId(11);
            System.out.println(P.getIdProveedor() + " " + P.getNombreProveedor());*/
            
        
        /*String UC = CLSRV.UpdateProveedor(11, "Tony", "Stark", "1", "1", "1", "1", "45");
        Proveedor P = CLSRV.SelectProveedorId(9);
            System.out.println(P.getIdProveedor() + " " + P.getNombreProveedor());*/
       
        
        /*Proveedor DC = CLSRV.DeleteProveedor(9);
        List PR = CLSRV.SelectAllProveedor();
            System.out.println(PR.size());*/ 
        
    }
    
}
    