package mx.edu.itspa.modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import mx.edu.itspa.general.Conexion;
import mx.edu.itspa.general.DetalleEntrega;
import mx.edu.itspa.general.DetalleVenta;
import mx.edu.itspa.general.Venta;

public class DetalleVentaDAO implements DetalleVentaCRUD{
    DetalleVenta DVDAO = new DetalleVenta();
    Conexion conexion = new Conexion();
    Connection C = null;
    PreparedStatement ps;
    ResultSet rs;


    @Override
    public List ListarDetalleFacturaVenta() {
        String SELECT_ALL_VENTA = "select * from DetalleFacturaVentas";            
        List<DetalleVenta> lista_detalle_venta = new ArrayList();
        
        try{
            C = conexion.Conectar();
            ps = C.prepareStatement(SELECT_ALL_VENTA);
            rs = ps.executeQuery();
                DetalleVenta detalle_venta;
            
            while(rs.next()){
                detalle_venta = new DetalleVenta();
                
                detalle_venta.setFolio_venta(rs.getInt(1));
                detalle_venta.setNombre_producto(rs.getString(2));
                detalle_venta.setCantidad_pieza(rs.getInt(3));
                detalle_venta.setTotal_pieza(rs.getDouble(4));
                detalle_venta.setFecha(rs.getString(5));
                  
                lista_detalle_venta.add(detalle_venta);
            }            
            
        } catch (Exception e){ 
        
        }        
        
        return lista_detalle_venta;
    }
    

    @Override
    public List ListarPorId(int folio_venta) {
        String SELECT_DETALLE = "select * from DetalleFacturaVentas where folio_venta=" + folio_venta;
            
        List<DetalleVenta> lista_dventa = new ArrayList();
        
        try{
            C = conexion.Conectar();
            ps = C.prepareStatement(SELECT_DETALLE);
            rs = ps.executeQuery();
                DetalleVenta dventa;
            
            while(rs.next()){
                dventa = new DetalleVenta();
                
                dventa.setFolio_venta(rs.getInt(1));
                dventa.setNombre_producto(rs.getString(2));
                dventa.setCantidad_pieza(rs.getInt(3));
                dventa.setTotal_pieza(rs.getDouble(4));
                dventa.setFecha(rs.getString(5));
                  
                lista_dventa.add(dventa);
            }            
            
        } catch (Exception e){ 
            
        }        
        
        return lista_dventa;
    }

    
    @Override
    public String Agregar(int folio_entrega, int id_producto, int cantidad_pieza) {
        String INSERT_DETALLE_VENTA = "insert into detalle_venta(folio_venta, id_producto, cantidad_pieza) values(?, ?, ?)";
            Venta venta = new Venta();
        
        try{
            C = conexion.Conectar();
            ps = C.prepareStatement(INSERT_DETALLE_VENTA);
            
            ps.setInt(1, folio_entrega);
            ps.setInt(2, id_producto);
            ps.setInt(3, cantidad_pieza);
            
                int res = ps.executeUpdate();
                
                if (res == 1) {
                    return "Venta agregada.";
                } else {
                    return "Error.";
                }
        } catch (NumberFormatException | SQLException e){  
            return "Error: " + e;
        }
        
    }
    
}
