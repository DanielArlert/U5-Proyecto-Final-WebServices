package mx.edu.itspa.general;

public class Producto {
    private int id_producto;
    private String nombre_producto;
    private int precio_compra;
    private int precio_venta;
    private String marca;
    private int stock;
    private String medidas;
	
    public Producto() { }

    public Producto(int id_producto, String nombre_producto, int precio_compra, 
            int precio_venta, String marca, int stock, String medidas) {
        this.id_producto = id_producto;
        this.nombre_producto = nombre_producto;
        this.precio_compra = precio_compra;
        this.precio_venta = precio_venta;
        this.marca = marca;
        this.stock = stock;
        this.medidas = medidas;
    } 

    public Producto(String nombre_producto, int precio_compra, 
            int precio_venta, String marca, int stock, String medidas) {
        this.nombre_producto = nombre_producto;
        this.precio_compra = precio_compra;
        this.precio_venta = precio_venta;
        this.marca = marca;
        this.stock = stock;
        this.medidas = medidas;
    } 

    public Producto(String nombre_producto, int precio_compra, 
            int precio_venta, String marca, int stock, String medidas, int id_producto) {
        this.nombre_producto = nombre_producto;
        this.precio_compra = precio_compra;
        this.precio_venta = precio_venta;
        this.marca = marca;
        this.stock = stock;
        this.medidas = medidas;
        this.id_producto = id_producto;
    } 
    
    public int getId_producto() { return id_producto; }
    public void setId_producto(int id_producto) { this.id_producto = id_producto; }

        public String getNombre_producto() { return nombre_producto; }
        public void setNombre_producto(String nombre_producto) { this.nombre_producto = nombre_producto; }

    public int getPrecio_compra() { return precio_compra; }
    public void setPrecio_compra(int precio_compra) { this.precio_compra = precio_compra; }

        public int getPrecio_venta() { return precio_venta; }
        public void setPrecio_venta(int precio_venta) { this.precio_venta = precio_venta; }

    public String getMarca() { return marca; }
    public void setMarca(String marca) { this.marca = marca; }

        public int getStock() { return stock; }
        public void setStock(int stock) { this.stock = stock; }

    public String getMedidas() { return medidas; }
    public void setMedidas(String medidas) { this.medidas = medidas; }
    
}
