package mx.edu.itspa.modelo;

import java.util.List;
import mx.edu.itspa.servicios.Entrega;

public class Entrega_Service {
    
    public Entrega_Service() { }
    
    public java.util.List<mx.edu.itspa.servicios.Entrega> ListarEntregas(){
        mx.edu.itspa.servicios.EntregaWebService_Service ESRV = new mx.edu.itspa.servicios.EntregaWebService_Service();
        mx.edu.itspa.servicios.EntregaWebService PORT = ESRV.getEntregaWebServicePort();
        
        return PORT.selectAllEntrega();
    }
        
    
    public int ProximaFacturaEntrega(){
        mx.edu.itspa.servicios.EntregaWebService_Service ESRV = new mx.edu.itspa.servicios.EntregaWebService_Service();
        mx.edu.itspa.servicios.EntregaWebService PORT = ESRV.getEntregaWebServicePort();
        
        return PORT.pfe();
    }
    
    
    public Entrega SelectEntregaId(int folio_entrega){
        mx.edu.itspa.servicios.EntregaWebService_Service ESRV = new mx.edu.itspa.servicios.EntregaWebService_Service();
        mx.edu.itspa.servicios.EntregaWebService PORT = ESRV.getEntregaWebServicePort();
        
        return PORT.selectEntregaId(folio_entrega);
    }
        
    
    public String Agregar(int folio_entrega, int id_proveedor) {
        mx.edu.itspa.servicios.EntregaWebService_Service ESRV = new mx.edu.itspa.servicios.EntregaWebService_Service();
        mx.edu.itspa.servicios.EntregaWebService PORT = ESRV.getEntregaWebServicePort();
        
        return PORT.agregarEntrega(folio_entrega, id_proveedor);
    }
    
    public static void main(String[] args) {
        Entrega_Service ESRV = new Entrega_Service();
                        
        /*List<Entrega> lista_entrega = ESRV.ListarEntregas();
            for(Entrega VEN: lista_entrega) {
                System.out.println(VEN.getFolioEntrega() + " " + VEN.getNombreProveedor());
            }*/
        
        
        /*Entrega V = ESRV.SelectEntregaId(1);
            System.out.println(V.getNombreProveedor());*/
        
        
        /*int SV = ESRV.ProximaFacturaEntrega();
            System.out.println(SV);*/
            
        
        /*String SSV = ESRV.Agregar(2, 5);
        List<Entrega> lista_entrega = ESRV.ListarEntregas();
            for(Entrega VEN: lista_entrega) {
                System.out.println(VEN.getFolioEntrega() + " " + VEN.getNombreProveedor());
            }*/          
    }
    
}
