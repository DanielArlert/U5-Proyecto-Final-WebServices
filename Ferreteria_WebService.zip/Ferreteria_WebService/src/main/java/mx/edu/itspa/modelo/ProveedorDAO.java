package mx.edu.itspa.modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import mx.edu.itspa.general.Conexion;
import mx.edu.itspa.general.Proveedor;

public class ProveedorDAO implements ProveedorCRUD{
    
    Conexion conexion = new Conexion();
    Connection C = null;
    Proveedor PRID = new Proveedor();
    PreparedStatement ps;
    ResultSet rs;
    int res;    

    @Override
    public List SelectAllProveedor() {
        String SELECT_ALL_PROVEEDOR = "select * from proveedor";
            List<Proveedor> lista_proveedor = new ArrayList<>();
            
        try{
            C = conexion.Conectar();
            ps = C.prepareStatement(SELECT_ALL_PROVEEDOR);
            rs = ps.executeQuery();
                Proveedor pro;
            
            while(rs.next()){
                pro = new Proveedor(
                    Integer.parseInt(rs.getString(1)), rs.getString(2), 
                        rs.getString(3), rs.getString(4), rs.getString(5)
                );
                
                  
                lista_proveedor.add(pro);
            } 
            
            C.close();
            
        } catch (NumberFormatException | SQLException e){  
            System.out.println("Error: " + e);
        }
        
        return lista_proveedor;    
    }
    

    @Override
    public Proveedor SelectProveedorId(int id_proveedor) {
        String SELECT_PROVEEDOR_ID = "select * from proveedor where id_proveedor=" + id_proveedor;
                        
        try{
            C = conexion.Conectar();
            ps = C.prepareStatement(SELECT_PROVEEDOR_ID);
            rs = ps.executeQuery();
            
            while(rs.next()){
                PRID.setId_proveedor(rs.getInt("id_proveedor"));
                PRID.setNombre_proveedor(rs.getString("nombre_proveedor"));    
                PRID.setApellidop_proveedor(rs.getString("apellidop_proveedor"));  
                PRID.setApellidom_proveedor(rs.getString("apellidom_proveedor"));  
                PRID.setCorreo(rs.getString("correo"));        
            } 
            
            C.close();
            
        } catch (NumberFormatException | SQLException e){  
            System.out.println("Error: " + e);
        }
        
        return PRID;   
    }

    
    @Override
    public String InsertProveedor(String nombre_proveedor, String apellidop_proveedor, String apellidom_proveedor, String correo) {
        String INSERT_PROVEEDOR = "insert into proveedor(nombre_proveedor, apellidop_proveedor, apellidom_proveedor, correo) values(?, ?, ?, ?)";
        
        try{
            C = conexion.Conectar();
            ps = C.prepareStatement(INSERT_PROVEEDOR);
            
            ps.setString(1, nombre_proveedor);
            ps.setString(2, apellidop_proveedor);
            ps.setString(3, apellidom_proveedor);
            ps.setString(4, correo);
                res = ps.executeUpdate();
                
                if (res == 1) {
                    return "Proveedor agregado.";
                } else {
                    return "Error.";
                }
        } catch (NumberFormatException | SQLException e){  
            return "Error: " + e;
        }
    }

    
    @Override
    public String UpdateProveedor(int id_proveedor, String nombre_proveedor, String apellidop_proveedor, String apellidom_proveedor, String correo) {
        String UPDATE_PROVEEDOR = "update proveedor set nombre_proveedor=?, apellidop_proveedor=?, apellidom_proveedor=?, correo=? where id_proveedor=" + id_proveedor;

        try{
            C = conexion.Conectar();
            ps = C.prepareStatement(UPDATE_PROVEEDOR);
            
            ps.setString(1, nombre_proveedor);
            ps.setString(2, apellidop_proveedor);
            ps.setString(3, apellidom_proveedor);
            ps.setString(4, correo);
                res = ps.executeUpdate();
                
                if (res == 1) {
                    return "Proveedor actualizado.";
                } else {
                    return "Error.";
                }
        } catch (NumberFormatException | SQLException e){  
            return "Error: " + e;
        }
    }

    
    @Override
    public Proveedor DeleteProveedor(int id_proveedor) {
        String DELETE_PROVEEDOR = "delete from proveedor where id_proveedor=" + id_proveedor;
        
        try{
            C = conexion.Conectar();
            ps = C.prepareStatement(DELETE_PROVEEDOR);
                res = ps.executeUpdate();
        } catch (NumberFormatException | SQLException e){  
            System.out.println("Error: " + e);
        }
          
        return PRID;  
    }
    
}
