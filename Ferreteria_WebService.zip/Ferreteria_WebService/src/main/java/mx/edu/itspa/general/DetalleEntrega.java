package mx.edu.itspa.general;

public class DetalleEntrega extends Entrega{
    private int id_producto;
    private String nombre_producto;
    private int cantidad_pieza;
    private double total_pieza;

    public DetalleEntrega( ) { }
    
    /*public DetalleEntrega(int id_producto, String nombre_producto, int cantidad_pieza, double total_pieza, int folio_entrega, int id_proveedor, String fecha, double total, String nombre_proveedor, String apellidop_proveedor, String apellidom_proveedor, String correo) {
        super(folio_entrega, id_proveedor, fecha, total, nombre_proveedor, apellidop_proveedor, apellidom_proveedor, correo);
        this.id_producto = id_producto;
        this.nombre_producto = nombre_producto;
        this.cantidad_pieza = cantidad_pieza;
        this.total_pieza = total_pieza;
    }
    
    public DetalleEntrega(String nombre_producto, int cantidad_pieza, double total_pieza, int folio_entrega, int id_proveedor, String fecha, double total, String nombre_proveedor, String apellidop_proveedor, String apellidom_proveedor, String correo) {
        super(folio_entrega, id_proveedor, fecha, total, nombre_proveedor, apellidop_proveedor, apellidom_proveedor, correo);
        this.nombre_producto = nombre_producto;
        this.cantidad_pieza = cantidad_pieza;
        this.total_pieza = total_pieza;
    }*/

    public int getId_producto() { return id_producto; }
    public void setId_producto(int id_producto) { this.id_producto = id_producto; }

        public String getNombre_producto() { return nombre_producto; }
        public void setNombre_producto(String nombre_producto) { this.nombre_producto = nombre_producto; }

    public int getCantidad_pieza() { return cantidad_pieza; }
    public void setCantidad_pieza(int cantidad_pieza) { this.cantidad_pieza = cantidad_pieza; }

        public double getTotal_pieza() { return total_pieza; }
        public void setTotal_pieza(double total_pieza) { this.total_pieza = total_pieza; }
}
