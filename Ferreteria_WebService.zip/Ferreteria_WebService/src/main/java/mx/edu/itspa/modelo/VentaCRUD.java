package mx.edu.itspa.modelo;

import java.util.List;
import mx.edu.itspa.general.Venta;

public interface VentaCRUD {
    
    public List ListarVentas();
    public int ProximaFacturaVenta();
    public Venta ListarVentasPorId(int folio_venta);
    public String Agregar(int folio_venta, int id_cliente);
    
}
