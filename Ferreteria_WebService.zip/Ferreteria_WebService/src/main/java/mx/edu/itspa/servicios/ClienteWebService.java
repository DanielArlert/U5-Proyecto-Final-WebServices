package mx.edu.itspa.servicios;

import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import mx.edu.itspa.general.Cliente;
import mx.edu.itspa.modelo.ClienteDAO;

@WebService(serviceName = "ClienteWebService")
public class ClienteWebService {

    ClienteDAO PDAO = new ClienteDAO();  
        
    @WebMethod(operationName = "SelectAllCliente")
    public List<Cliente> SelectAllCliente() {
        List ListadoClientes = PDAO.SelectAllCliente();
        
        return ListadoClientes;
    }
    
    

    @WebMethod(operationName = "InsertCliente")
    public String InsertCliente(
            @WebParam(name = "nombre_cliente") String nombre_cliente,
            @WebParam(name = "apellidop_cliente") String apellidop_cliente,
            @WebParam(name = "apellidom_cliente") String apellidom_cliente,
            @WebParam(name = "calle") String calle,
            @WebParam(name = "numero") String numero,
            @WebParam(name = "ciudad") String ciudad,
            @WebParam(name = "telefono") String telefono
    ) {
        
        String consulta = PDAO.InsertCliente(nombre_cliente, apellidop_cliente, apellidom_cliente, calle, numero, ciudad, telefono);
        
        return consulta;
    }
    
    

    @WebMethod(operationName = "SelectClienteId")
    public Cliente SelectClienteId(@WebParam(name="id_cliente") int id_cliente){
        Cliente C = PDAO.SelectClienteId(id_cliente);
        
        return C;
    }
    
    

    @WebMethod(operationName = "UpdateCliente")
    public String updateCliente(
            @WebParam(name = "id_cliente") int id_cliente,
            @WebParam(name = "nombre_cliente") String nombre_cliente,
            @WebParam(name = "apellidop_cliente") String apellidop_cliente,
            @WebParam(name = "apellidom_cliente") String apellidom_cliente,
            @WebParam(name = "calle") String calle,
            @WebParam(name = "numero") String numero,
            @WebParam(name = "ciudad") String ciudad,
            @WebParam(name = "telefono") String telefono
    ) {
        
        String consulta = PDAO.UpdateCliente(id_cliente, nombre_cliente, apellidop_cliente, apellidom_cliente, calle, numero, ciudad, telefono);
        
        return consulta;
    }
    
    

    @WebMethod(operationName = "DeleteCliente")
    public Cliente DeleteCliente(@WebParam(name="id_cliente") int id_cliente){
        Cliente C = PDAO.DeleteCliente(id_cliente);
        
        return C;
    }
    
}
