package mx.edu.itspa.modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import mx.edu.itspa.general.Conexion;
import mx.edu.itspa.general.DetalleEntrega;
import mx.edu.itspa.general.Entrega;

public class DetalleEntregaDAO implements DetalleEntregaCRUD{
    DetalleEntrega DEDAO = new DetalleEntrega();
    Conexion conexion = new Conexion();
    Connection C = null;
    PreparedStatement ps;
    ResultSet rs;

    
    @Override
    public List ListarDetalleFacturaEntrega() {
        String SELECT_ALL_ENTREGA = "select * from DetalleFacturaEntregas";            
        List<DetalleEntrega> lista_detalle_entrega = new ArrayList();
        
        try{
            C = conexion.Conectar();
            ps = C.prepareStatement(SELECT_ALL_ENTREGA);
            rs = ps.executeQuery();
                DetalleEntrega detalle_entrega;
            
            while(rs.next()){
                detalle_entrega = new DetalleEntrega();
                
                detalle_entrega.setFolio_entrega(rs.getInt(1));
                detalle_entrega.setNombre_producto(rs.getString(2));
                detalle_entrega.setCantidad_pieza(rs.getInt(3));
                detalle_entrega.setTotal_pieza(rs.getDouble(4));
                detalle_entrega.setFecha(rs.getString(5));
                  
                lista_detalle_entrega.add(detalle_entrega);
            }            
            
        } catch (Exception e){ }
        
        
        return lista_detalle_entrega;
    }

    @Override
    public List ListarPorId(int folio_entrega) {
        String SELECT_DETALLE = "select * from DetalleFacturaEntregas where folio_entrega="+folio_entrega;
            
        List<DetalleEntrega> lista_dentrega = new ArrayList();
        
        try{
            C = conexion.Conectar();
            ps = C.prepareStatement(SELECT_DETALLE);
            rs = ps.executeQuery();
                DetalleEntrega dentrega;
            
            while(rs.next()){
                dentrega = new DetalleEntrega();
                
                dentrega.setFolio_entrega(rs.getInt(1));
                dentrega.setNombre_producto(rs.getString(2));
                dentrega.setCantidad_pieza(rs.getInt(3));
                dentrega.setTotal_pieza(rs.getDouble(4));
                dentrega.setFecha(rs.getString(5));
                  
                lista_dentrega.add(dentrega);
            }            
            
        } catch (Exception e){ 
            
        }        
        
        return lista_dentrega;
    }
    

    @Override
    public String Agregar(int folio_entrega, int id_producto, int cantidad_pieza) {
        String INSERT_DETALLE_ENTREGA = "insert into detalle_entrega(folio_entrega, id_producto, cantidad_pieza) values(?, ?, ?)";
            Entrega entrega = new Entrega();
        
        try{
            C = conexion.Conectar();
            ps = C.prepareStatement(INSERT_DETALLE_ENTREGA);
            
            ps.setInt(1, folio_entrega);
            ps.setInt(2, id_producto);
            ps.setInt(3, cantidad_pieza);
            
                int res = ps.executeUpdate();
                
                if (res == 1) {
                    return "Entrega agregada.";
                } else {
                    return "Error.";
                }
        } catch (NumberFormatException | SQLException e){  
            return "Error: " + e;
        }
        
    }
    
}

