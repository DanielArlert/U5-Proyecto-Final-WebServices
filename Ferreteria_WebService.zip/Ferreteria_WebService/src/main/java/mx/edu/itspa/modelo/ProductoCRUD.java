package mx.edu.itspa.modelo;

import java.util.List;
import mx.edu.itspa.general.Producto;

public interface ProductoCRUD {
    
    public List SelectAllProducto();
    public Producto SelectProductoId(int id_producto);
    public String InsertProducto(String nombre_producto, int precio_compra, int precio_venta, String marca, int stock, String medidas);
    public String UpdateProducto(int id_producto, String nombre_producto, int precio_compra, int precio_venta, String marca, int stock, String medidas);
    public Producto DeleteProducto(int id_producto);
    
}
