package mx.edu.itspa.modelo;

import java.util.List;
import mx.edu.itspa.servicios.Venta;

public class Venta_Service {
    
    public Venta_Service() { }
    
    public java.util.List<mx.edu.itspa.servicios.Venta> ListarVentas(){
        mx.edu.itspa.servicios.VentaWebService_Service VSRV = new mx.edu.itspa.servicios.VentaWebService_Service();
        mx.edu.itspa.servicios.VentaWebService PORT = VSRV.getVentaWebServicePort();
        
        return PORT.selectAllVenta();
    }
        
    
    public int ProximaFacturaVenta(){
        mx.edu.itspa.servicios.VentaWebService_Service VSRV = new mx.edu.itspa.servicios.VentaWebService_Service();
        mx.edu.itspa.servicios.VentaWebService PORT = VSRV.getVentaWebServicePort();
        
        return PORT.pfv();
    }
    
    
    public Venta SelectVentaId(int folio_venta){
        mx.edu.itspa.servicios.VentaWebService_Service VSRV = new mx.edu.itspa.servicios.VentaWebService_Service();
        mx.edu.itspa.servicios.VentaWebService PORT = VSRV.getVentaWebServicePort();
        
        return PORT.selectVentaId(folio_venta);
    }
        
    
    public String Agregar(int folio_venta, int id_cliente) {
        mx.edu.itspa.servicios.VentaWebService_Service VSRV = new mx.edu.itspa.servicios.VentaWebService_Service();
        mx.edu.itspa.servicios.VentaWebService PORT = VSRV.getVentaWebServicePort();
        
        return PORT.agregarVenta(folio_venta, id_cliente);
    }
    
    public static void main(String[] args) {
        Venta_Service VSRV = new Venta_Service();
                        
        /*List<Venta> lista_venta = VSRV.ListarVentas();
            for(Venta VEN: lista_venta) {
                System.out.println(VEN.getFolioVenta() + " " + VEN.getNombreCliente());
            }*/
        
        
        /*Venta V = VSRV.SelectVentaId(1);
            System.out.println(V.getNombreCliente());*/
        
        
        /*int SV = VSRV.ProximaFacturaVenta();
            System.out.println(SV);*/
            
        
        /*String SSV = VSRV.Agregar(2, 5);
        List<Venta> lista_venta = VSRV.ListarVentas();
            for(Venta VEN: lista_venta) {
                System.out.println(VEN.getFolioVenta() + " " + VEN.getNombreCliente());
            }*/          
    }
    
}
