package mx.edu.itspa.general;

public class Entrega extends Proveedor{
    private int folio_entrega;
    private int id_proveedor;
    private String fecha;
    private double total;

    public Entrega() {    }

    public Entrega(int folio_entrega, int id_proveedor) {
        this.folio_entrega = folio_entrega;
        this.id_proveedor = id_proveedor;
    }
    

    public int getFolio_entrega() { return folio_entrega; }
    public void setFolio_entrega(int folio_entrega) { this.folio_entrega = folio_entrega; }

        public int getId_proveedor() { return id_proveedor; }
        public void setId_proveedor(int id_proveedor) { this.id_proveedor = id_proveedor; }

    public String getFecha() { return fecha; }
    public void setFecha(String fecha) { this.fecha = fecha; }

        public double getTotal() { return total; }
        public void setTotal(double total) { this.total = total; }
}
