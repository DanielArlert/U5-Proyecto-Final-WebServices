package mx.edu.itspa.modelo;

import java.util.List;
import mx.edu.itspa.servicios.DetalleVenta;

public class DetalleVenta_Service {
    
    public DetalleVenta_Service() { }
    
    public java.util.List<mx.edu.itspa.servicios.DetalleVenta> ListarDetalleFacturaVenta(){
        mx.edu.itspa.servicios.DetalleVentaWebService_Service DVSRV = new mx.edu.itspa.servicios.DetalleVentaWebService_Service();
        mx.edu.itspa.servicios.DetalleVentaWebService PORT = DVSRV.getDetalleVentaWebServicePort();
        
        return PORT.listarDetalleFacturaVenta();
    }
    
    
    public java.util.List<mx.edu.itspa.servicios.DetalleVenta> ListarPorId(int folio_venta){
        mx.edu.itspa.servicios.DetalleVentaWebService_Service DVSRV = new mx.edu.itspa.servicios.DetalleVentaWebService_Service();
        mx.edu.itspa.servicios.DetalleVentaWebService PORT = DVSRV.getDetalleVentaWebServicePort();
        
        return PORT.listarDetalleVentaPorId(folio_venta);
    }
    
    
    public String Agregar(int folio_venta, int id_producto, int cantidad_pieza) {
        mx.edu.itspa.servicios.DetalleVentaWebService_Service DVSRV = new mx.edu.itspa.servicios.DetalleVentaWebService_Service();
        mx.edu.itspa.servicios.DetalleVentaWebService PORT = DVSRV.getDetalleVentaWebServicePort();
        
        return PORT.agregarDetalleVenta(folio_venta, id_producto, cantidad_pieza);
    }
    
    public static void main(String[] args) {
        DetalleVenta_Service DVSRV = new DetalleVenta_Service();
                
        /*List<DetalleVenta> LDV = DVSRV.ListarDetalleFacturaVenta();
            for(DetalleVenta D_V : LDV) {
                System.out.println(D_V.getNombreProducto());
            }*/
        
        
        /*List<DetalleVenta> LDV = DVSRV.ListarPorId(1);
            for(DetalleVenta D_V : LDV) {
                System.out.println(D_V.getNombreProducto());
            }*/        
            
        
        /*String SDE = DVSRV.Agregar(2, 5, 5);
        List<DetalleVenta> LDV = DVSRV.ListarDetalleFacturaVenta();
            for(DetalleVenta D_V : LDV) {
                System.out.println(D_V.getNombreProducto());
            }*/                         
    }
    
}
