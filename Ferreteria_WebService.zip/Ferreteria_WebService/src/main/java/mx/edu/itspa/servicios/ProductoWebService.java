package mx.edu.itspa.servicios;

import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import mx.edu.itspa.general.Producto;
import mx.edu.itspa.modelo.ProductoDAO;

@WebService(serviceName = "ProductoWebService")
public class ProductoWebService {

    ProductoDAO PDAO = new ProductoDAO();
        
    @WebMethod(operationName = "SelectAllProducto")
    public List<Producto> SelectAllProducto() {
        List ListadoProductos = PDAO.SelectAllProducto();
        
        return ListadoProductos;
    }
    
    

    @WebMethod(operationName = "InsertProducto")
    public String InsertProducto(
            @WebParam(name = "nombre_producto") String nombre_producto,
            @WebParam(name = "precio_compra") int precio_compra,
            @WebParam(name = "precio_venta") int precio_venta,
            @WebParam(name = "marca") String marca,
            @WebParam(name = "stock") int stock,
            @WebParam(name = "medidas") String medidas
    ) {
        
        String consulta = PDAO.InsertProducto(nombre_producto, precio_compra, precio_venta, marca, stock, medidas);
        
        return consulta;
    }
    
    

    @WebMethod(operationName = "SelectProductoId")
    public Producto SelectProductoId(@WebParam(name="id_producto") int id_producto){
        Producto P = PDAO.SelectProductoId(id_producto);
        
        return P;
    }
    
    

    @WebMethod(operationName = "UpdateProducto")
    public String updateProducto(
            @WebParam(name = "id_producto") int id_producto,
            @WebParam(name = "nombre_producto") String nombre_producto,
            @WebParam(name = "precio_compra") int precio_compra,
            @WebParam(name = "precio_venta") int precio_venta,
            @WebParam(name = "marca") String marca,
            @WebParam(name = "stock") int stock,
            @WebParam(name = "medidas") String medidas
    ) {
        
        String consulta = PDAO.UpdateProducto(id_producto, nombre_producto, precio_compra, precio_venta, marca, stock, medidas);
        
        return consulta;
    }
    
    

    @WebMethod(operationName = "DeleteProducto")
    public Producto DeleteProducto(@WebParam(name="id_producto") int id_producto){
        Producto P = PDAO.DeleteProducto(id_producto);
        
        return P;
    }
    
}
