package mx.edu.itspa.general;

public class Cliente {
    private int id_cliente;
    private String nombre_cliente;
    private String apellidop_cliente;
    private String apellidom_cliente;
    private String calle;
    private String numero;
    private String ciudad;
    private String telefono;

    public Cliente() { }

    public Cliente(String nombre_cliente) {
        this.nombre_cliente = nombre_cliente;
    }

    public Cliente(String nombre_cliente, String apellidop_cliente, String apellidom_cliente) {
        this.nombre_cliente = nombre_cliente;
        this.apellidop_cliente = apellidop_cliente;
        this.apellidom_cliente = apellidom_cliente;
    }

    public Cliente(int id_cliente, String nombre_cliente, String apellidop_cliente, String apellidom_cliente, 
                    String calle, String numero, String ciudad, String telefono) {
        this.id_cliente = id_cliente;
        this.nombre_cliente = nombre_cliente;
        this.apellidop_cliente = apellidop_cliente;
        this.apellidom_cliente = apellidom_cliente;
        this.calle = calle;
        this.numero = numero;
        this.ciudad = ciudad;
        this.telefono = telefono;
    }

    public Cliente(String nombre_cliente, String apellidop_cliente, String apellidom_cliente, 
                    String calle, String numero, String ciudad, String telefono) {
        this.nombre_cliente = nombre_cliente;
        this.apellidop_cliente = apellidop_cliente;
        this.apellidom_cliente = apellidom_cliente;
        this.calle = calle;
        this.numero = numero;
        this.ciudad = ciudad;
        this.telefono = telefono;
    }

    public int getId_cliente() { return id_cliente; }
    public void setId_cliente(int id_cliente) { this.id_cliente = id_cliente; }
    
        public String getNombre_cliente() { return nombre_cliente; }
        public void setNombre_cliente(String nombre_cliente) { this.nombre_cliente = nombre_cliente; }

            public String getApellidop_cliente() { return apellidop_cliente; }
            public void setApellidop_cliente(String apellidop_cliente) { this.apellidop_cliente = apellidop_cliente; }

            public String getApellidom_cliente() { return apellidom_cliente; }
            public void setApellidom_cliente(String apellidom_cliente) { this.apellidom_cliente = apellidom_cliente; }

    public String getCalle() { return calle; }
    public void setCalle(String calle) { this.calle = calle; }

        public String getNumero() { return numero; }
        public void setNumero(String numero) { this.numero = numero; }

    public String getCiudad() { return ciudad; }
    public void setCiudad(String ciudad) { this.ciudad = ciudad; }

        public String getTelefono() { return telefono; }
        public void setTelefono(String telefono) { this.telefono = telefono; }
}
