package mx.edu.itspa.modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import mx.edu.itspa.general.Conexion;
import mx.edu.itspa.general.Producto;

public class ProductoDAO implements ProductoCRUD {
    
    Conexion conexion = new Conexion();
    Connection C = null;
    Producto PID = new Producto();
    PreparedStatement ps;
    ResultSet rs;
    int res;    
    
    @Override
    public List SelectAllProducto() {
        String SELECT_ALL_PRODUCTO = "select * from producto";
            List<Producto> lista_producto = new ArrayList<>();
            
        try{
            C = conexion.Conectar();
            ps = C.prepareStatement(SELECT_ALL_PRODUCTO);
            rs = ps.executeQuery();
                Producto pdt;
            
            while(rs.next()){
                pdt = new Producto(
                    Integer.parseInt(rs.getString(1)),  
                        rs.getString(2),
                    Integer.parseInt(rs.getString(3)),  
                        Integer.parseInt(rs.getString(4)),
                    rs.getString(5),                    
                        Integer.parseInt(rs.getString(6)),  
                    rs.getString(7)
                );
                
                lista_producto.add(pdt);
            } 
            
            C.close();
            
        } catch (NumberFormatException | SQLException e){  
            System.out.println("Error: " + e);
        }
        
        return lista_producto;    
    }

    
    
    @Override
    public Producto SelectProductoId(int id_producto) {
        String SELECT_PRODUCTO_ID = "select * from producto where id_producto=" + id_producto;
                        
        try{
            C = conexion.Conectar();
            ps = C.prepareStatement(SELECT_PRODUCTO_ID);
            rs = ps.executeQuery();
            
            while(rs.next()){
                PID.setId_producto(rs.getInt("id_producto"));
                PID.setNombre_producto(rs.getString("nombre_producto"));
                PID.setPrecio_compra(rs.getInt("precio_compra"));
                PID.setPrecio_venta(rs.getInt("precio_venta"));
                PID.setMarca(rs.getString("marca"));
                PID.setStock(rs.getInt("stock"));
                PID.setMedidas(rs.getString("medidas"));                
            } 
            
            C.close();
            
        } catch (NumberFormatException | SQLException e){  
            System.out.println("Error: " + e);
        }
        
        return PID;       
    }

    
    
    @Override
    public String InsertProducto(String nombre_producto, int precio_compra, int precio_venta, String marca, int stock, String medidas) {
        String INSERT_PRODUCTO = "insert into producto(nombre_producto, precio_compra, precio_venta, marca, stock, medidas) values(?, ?, ?, ?, ?, ?)";
                
        try{
            C = conexion.Conectar();
            ps = C.prepareStatement(INSERT_PRODUCTO);
            
            ps.setString(1, nombre_producto);
            ps.setInt(2, precio_compra);
            ps.setInt(3, precio_venta);
            ps.setString(4, marca);
            ps.setInt(5, stock);
            ps.setString(6, medidas);
                res = ps.executeUpdate();
                
                if (res == 1) {
                    return "Producto agregado.";
                } else {
                    return "Error.";
                }
        } catch (NumberFormatException | SQLException e){  
            return "Error: " + e;
        }
        
        
    }

    
    
    @Override
    public String UpdateProducto(int id_producto, String nombre_producto, int precio_compra, int precio_venta, String marca, int stock, String medidas) {
        String UPDATE_PRODUCTO = "update producto set nombre_producto=?, precio_compra=?, precio_venta=?, marca=?, stock=?, medidas=? where id_producto="+id_producto;
        
        try{
            C = conexion.Conectar();
            ps = C.prepareStatement(UPDATE_PRODUCTO);
            
            ps.setString(1, nombre_producto);
            ps.setInt(2, precio_compra);
            ps.setInt(3, precio_venta);
            ps.setString(4, marca);
            ps.setInt(5, stock);
            ps.setString(6, medidas);
                res = ps.executeUpdate();
                
                if (res == 1) {
                    return "Producto actualizado.";
                } else {
                    return "Error.";
                }
        } catch (NumberFormatException | SQLException e){  
            return "Error: " + e;
        }
        
    }

    
    
    @Override
    public Producto DeleteProducto(int id_producto) {
        String DELETE_PRODUCTO = "delete from producto where id_producto="+id_producto;
        
        try{
            C = conexion.Conectar();
            ps = C.prepareStatement(DELETE_PRODUCTO);
                res = ps.executeUpdate();
        } catch (NumberFormatException | SQLException e){  
            System.out.println("Error: " + e);
        }
          
        return PID;  
    }
    
}
