package mx.edu.itspa.modelo;

import java.util.List;
import mx.edu.itspa.servicios.Cliente;

public class Cliente_Service {
    
    public Cliente_Service() { }
    
    
    public java.util.List<mx.edu.itspa.servicios.Cliente> SelectAllCliente(){
        mx.edu.itspa.servicios.ClienteWebService_Service PSRV = new mx.edu.itspa.servicios.ClienteWebService_Service();
        mx.edu.itspa.servicios.ClienteWebService PORT = PSRV.getClienteWebServicePort();
        
        return PORT.selectAllCliente();
    }
        
    
    public String InsertCliente(java.lang.String nombre_cliente, java.lang.String apellidop_cliente, java.lang.String apellidom_cliente, java.lang.String calle, java.lang.String numero, java.lang.String ciudad, java.lang.String telefono){
        mx.edu.itspa.servicios.ClienteWebService_Service PSRV = new mx.edu.itspa.servicios.ClienteWebService_Service();
        mx.edu.itspa.servicios.ClienteWebService PORT = PSRV.getClienteWebServicePort();
        
        return PORT.insertCliente(nombre_cliente, apellidop_cliente, apellidom_cliente, calle, numero, ciudad, telefono);
    }
    
    
    public Cliente SelectClienteId(int id_cliente){
        mx.edu.itspa.servicios.ClienteWebService_Service PSRV = new mx.edu.itspa.servicios.ClienteWebService_Service();
        mx.edu.itspa.servicios.ClienteWebService PORT = PSRV.getClienteWebServicePort();
        
        return PORT.selectClienteId(id_cliente);
    }
        
    
    public String UpdateCliente(int id_cliente, java.lang.String nombre_cliente, java.lang.String apellidop_cliente, java.lang.String apellidom_cliente, java.lang.String calle, java.lang.String numero, java.lang.String ciudad, java.lang.String telefono){
        mx.edu.itspa.servicios.ClienteWebService_Service PSRV = new mx.edu.itspa.servicios.ClienteWebService_Service();
        mx.edu.itspa.servicios.ClienteWebService PORT = PSRV.getClienteWebServicePort();
        
        return PORT.updateCliente(id_cliente, nombre_cliente, apellidop_cliente, apellidom_cliente, calle, numero, ciudad, telefono);
    }
    

    public Cliente DeleteCliente(int id_cliente){
        mx.edu.itspa.servicios.ClienteWebService_Service PSRV = new mx.edu.itspa.servicios.ClienteWebService_Service();
        mx.edu.itspa.servicios.ClienteWebService PORT = PSRV.getClienteWebServicePort();
        
        return PORT.deleteCliente(id_cliente);
    }  
    
    public static void main(String[] args) {
        Cliente_Service CLSRV = new Cliente_Service();
        
        //System.out.println("Producto");    
        
        /*List PR = CLSRV.SelectAllCliente();
        System.out.println(PR.size());*/
        
        
        //String IP = CLSRV.InsertCliente("1", "1", "1", "1", "1", "1", "1");
                
        
        /*Cliente P = CLSRV.SelectClienteId(11);
            System.out.println(P.getIdCliente() + " " + P.getNombreCliente());*/
            
        
        /*String UC = CLSRV.UpdateCliente(11, "Tony", "Stark", "1", "1", "1", "1", "45");
        Cliente P = CLSRV.SelectClienteId(9);
            System.out.println(P.getIdCliente() + " " + P.getNombreCliente());*/
       
        
        /*Cliente DC = CLSRV.DeleteCliente(9);
        List PR = CLSRV.SelectAllCliente();
            System.out.println(PR.size());*/ 
        
    }
    
}
