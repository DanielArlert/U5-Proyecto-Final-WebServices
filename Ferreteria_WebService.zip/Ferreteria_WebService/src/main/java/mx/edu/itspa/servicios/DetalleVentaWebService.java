package mx.edu.itspa.servicios;

import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import mx.edu.itspa.general.DetalleVenta;
import mx.edu.itspa.modelo.DetalleVentaDAO;

@WebService(serviceName = "DetalleVentaWebService")
public class DetalleVentaWebService {

    DetalleVentaDAO DVDAO = new DetalleVentaDAO();
    
    @WebMethod(operationName = "ListarDetalleFacturaVenta")
    public List<DetalleVenta> ListarDetalleFacturaVenta(){
        List LDE = DVDAO.ListarDetalleFacturaVenta();
        
        return LDE;
    }
    

    @WebMethod(operationName = "ListarDetalleVentaPorId")
    public List<DetalleVenta> ListarDetalleVentaPorId(@WebParam(name="folio_venta") int folio_venta){
        List LDE = DVDAO.ListarPorId(folio_venta);
        
        return LDE;
    }
    
    
    @WebMethod(operationName = "AgregarDetalleVenta")
    public String AgregarDetalleVenta(
            @WebParam(name = "folio_venta") int folio_venta,
            @WebParam(name = "id_producto") int id_producto,
            @WebParam(name = "cantidad_pieza") int cantidad_pieza
    ) {
        
        String consulta = DVDAO.Agregar(folio_venta, id_producto, cantidad_pieza);
        
        return consulta;
    } 
    
}