package mx.edu.itspa.servicios;

import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import mx.edu.itspa.general.Venta;
import mx.edu.itspa.modelo.VentaDAO;

@WebService(serviceName = "VentaWebService")
public class VentaWebService {

    VentaDAO VDAO = new VentaDAO();

    @WebMethod(operationName = "SelectAllVenta")
    public List<Venta> SelectAllVenta() {
        List ListadoVentas = VDAO.ListarVentas();
        
        return ListadoVentas;
    }
    
    

    @WebMethod(operationName = "PFV")
    public int PFV( ) {
        
        return VDAO.ProximaFacturaVenta();
    }
    
    

    @WebMethod(operationName = "SelectVentaId")
    public Venta SelectVentaId(@WebParam(name="folio_venta") int folio_venta){
        Venta V = VDAO.ListarVentasPorId(folio_venta);
        
        return V;
    }
    
    

    @WebMethod(operationName = "AgregarVenta")
    public String AgregarVenta(
            @WebParam(name = "folio_venta") int folio_venta,
            @WebParam(name = "id_cliente") int id_cliente
    ) {
        
        String consulta = VDAO.Agregar(folio_venta, id_cliente);
        
        return consulta;
    } 
    
}
