package mx.edu.itspa.servicios;

import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import mx.edu.itspa.general.Entrega;
import mx.edu.itspa.modelo.EntregaDAO;

@WebService(serviceName = "EntregaWebService")
public class EntregaWebService {

    EntregaDAO EDAO = new EntregaDAO();

    @WebMethod(operationName = "SelectAllEntrega")
    public List<Entrega> SelectAllEntrega() {
        List ListadoEntregas = EDAO.ListarEntregas();
        
        return ListadoEntregas;
    }
    
    
    @WebMethod(operationName = "PFE")
    public int PFE( ) {
        
        return EDAO.ProximaFacturaEntrega();
    }
    
    
    @WebMethod(operationName = "SelectEntregaId")
    public Entrega SelectEntregaId(@WebParam(name="folio_entrega") int folio_entrega){
        Entrega E = EDAO.ListarEntregasPorId(folio_entrega);
        
        return E;
    }
    
    @WebMethod(operationName = "AgregarEntrega")
    public String AgregarEntrega(
            @WebParam(name = "folio_entrega") int folio_entrega,
            @WebParam(name = "id_proveedor") int id_proveedor
    ) {
        
        String consulta = EDAO.Agregar(folio_entrega, id_proveedor);
        
        return consulta;
    }
    
}
